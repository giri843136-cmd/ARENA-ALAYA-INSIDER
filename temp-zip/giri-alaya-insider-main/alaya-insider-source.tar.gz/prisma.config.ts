import { defineConfig } from "prisma/config";

export default defineConfig({
  schema: "prisma/schema.prisma",
  // Prisma 7: Connection URL via env (DATABASE_URL).
  // For preview / no-DB environments, we allow the app to run with stubbed client.
  // CLI (migrate/seed) will warn if no DB but not block preview.
  // In real deployment: set DATABASE_URL to Postgres and run db:migrate + db:seed.
});
