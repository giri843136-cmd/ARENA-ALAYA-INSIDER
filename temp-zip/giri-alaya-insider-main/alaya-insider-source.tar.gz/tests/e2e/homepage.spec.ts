import { test, expect } from '@playwright/test';

test('homepage loads and shows key sections', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1')).toContainText(/ALAYA|sanctuary|curated/i);
  await expect(page.locator('text=The Edit')).toBeVisible();
  // Add more frozen-UI smoke tests here
});
