import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { rateLimit, getClientIP } from './lib/backend/security/rate-limit';

export async function middleware(request: NextRequest) {
  const ip = getClientIP(request as any);
  const path = request.nextUrl.pathname;

  // Basic rate limiting on API routes
  if (path.startsWith('/api/')) {
    const { allowed } = rateLimit(ip, 120, 60000); // 120 req/min
    if (!allowed) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429 });
    }
  }

  // Admin protection (basic)
  if (path.startsWith('/admin') && !request.cookies.get('next-auth.session-token')) {
    // In real flow this is handled by page-level requireAuth
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/api/:path*', '/admin/:path*'],
};
