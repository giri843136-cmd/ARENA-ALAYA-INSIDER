"use client";

export default function SystemSettings() {
  return (
    <div className="p-8 max-w-2xl">
      <div className="mb-8">
        <div className="text-xs tracking-[2.5px] text-[#C5AA8A]">PLATFORM</div>
        <h1 className="text-[42px] font-semibold tracking-[-1.2px] mt-1">System Settings</h1>
      </div>

      <div className="space-y-8">
        <div>
          <div className="text-xs tracking-[2px] text-[#C5AA8A] mb-3">SITE</div>
          <div className="admin-card p-6 space-y-4 text-sm">
            <div className="flex justify-between">Maintenance Mode <span className="text-[#4ADE80]">OFF</span></div>
            <div className="flex justify-between">Public Site Status <span className="text-[#4ADE80]">LIVE</span></div>
            <div className="flex justify-between">CDN Cache <span className="text-[#C5AA8A]">99.8% hit rate</span></div>
          </div>
        </div>

        <div>
          <div className="text-xs tracking-[2px] text-[#C5AA8A] mb-3">AI &amp; PERSONALIZATION</div>
          <div className="admin-card p-6 text-sm space-y-3">
            <div>Default model: Claude 3.7 Sonnet (Opus priority enabled)</div>
            <div>Personal AI Concierge: Active • 1,847 generations today</div>
            <div>Recommendation graph: Fresh (refreshed 4m ago)</div>
          </div>
        </div>

        <div>
          <div className="text-xs tracking-[2px] text-[#C5AA8A] mb-3">INTEGRATIONS</div>
          <div className="admin-card p-6 text-sm">Typesense, Upstash Redis, BullMQ queues, Stripe, all healthy.</div>
        </div>

        <button className="btn-admin-primary" onClick={() => alert("Settings saved (demo — all production config frozen)")}>Save Changes</button>
      </div>

      <div className="text-xs text-[#666] mt-10">All production readiness work (Docker, PM2, Nginx, workers, env validation, backups) remains frozen and untouched.</div>
    </div>
  );
}
