1:I[57121,[],"LoadingBoundaryProvider"]
2:"$Sreact.fragment"
3:I[57121,[],""]
4:I[74581,[],""]
5:[]
0:{"rsc":["$","$L1",null,{"loading":[["$","div","l",{"className":"p-8","children":["$","div",null,{"className":"flex flex-col items-center justify-center py-20 text-center","children":[["$","div",null,{"className":"h-8 w-8 border-2 border-[#E4DDD5] border-t-[#7A6848] rounded-full animate-spin mb-4"}],["$","p",null,{"className":"text-sm tracking-widest text-[#5C5249]","children":"Loading the brand vault..."}]]}]}],[],[]],"children":["$","$2","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}]}],"isPartial":false,"staleTime":300,"varyParams":"$W5","buildId":"TiN-BSIYso5yClXvCCcom"}
