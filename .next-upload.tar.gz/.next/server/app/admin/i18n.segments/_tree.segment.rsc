:HL["/_next/static/css/3a60ec968edd61a3.css","style"]
:HL["/_next/static/css/a7e0b95d2734f390.css","style"]
:HL["/_next/static/css/f2a6b6e248312573.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":28,"slots":{"children":{"name":"(admin)","param":null,"prefetchHints":8,"slots":{"children":{"name":"admin","param":null,"prefetchHints":4,"slots":{"children":{"name":"i18n","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"TiN-BSIYso5yClXvCCcom"}
